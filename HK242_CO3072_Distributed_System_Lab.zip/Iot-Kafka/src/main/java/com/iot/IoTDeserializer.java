package com.iot;

import org.apache.kafka.common.serialization.Deserializer;
import com.fasterxml.jackson.databind.ObjectMapper;

public class IoTDeserializer<T> implements Deserializer<T> {
    private ObjectMapper objectMapper;
    private Class<T> dataClass;

    public IoTDeserializer(Class<T> dataClass) {
        this.dataClass = dataClass;
        this.objectMapper = new ObjectMapper();
        objectMapper.findAndRegisterModules();
    }

    @Override
    public T deserialize(String topic, byte[] data) {
        try {
            return objectMapper.readValue(data, dataClass);
        } catch (Exception e) {
            throw new RuntimeException("Error deserializing JSON message of object " + dataClass + " ", e);
        }
    }
}

package com.iot;

import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.Properties;
import java.time.Duration;
import java.util.Collections;

public class IotConsumer {
    public static void main(String[] args) {
        int numPartitions = 3;
        String[] topics = {"air", "earth", "water"};
        String[] consumerGroups = {"air-group", "earth-group", "water-group"};

        ExecutorService executor = Executors.newFixedThreadPool(numPartitions * topics.length);

        for (int i = 0; i < topics.length; i++) {
            for (int j = 0; j < numPartitions; j++) {
                executor.execute(new ConsumerTask(topics[i], consumerGroups[i], j));
            }
        }

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("Shutting down consumers...");
            executor.shutdown();
            try {
                if (!executor.awaitTermination(10, TimeUnit.SECONDS)) {
                    executor.shutdownNow();
                }
            } catch (InterruptedException e) {
                executor.shutdownNow();
            }
        }));
    }
}

class ConsumerTask implements Runnable {
    private String topic;
    private String consumerGroup;
    private int partition;

    public ConsumerTask(String topic, String consumerGroup, int partition) {
        this.topic = topic;
        this.consumerGroup = consumerGroup;
        this.partition = partition;
    }

    @Override
    public void run() {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:19092,localhost:29092");
        props.put(ConsumerConfig.GROUP_ID_CONFIG, this.consumerGroup);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "com.iot.IoTDeserializer");
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");

        Consumer<String, Object> consumer = new KafkaConsumer<>(props);
        TopicPartition topicPartition = new TopicPartition(this.topic, this.partition);
        consumer.assign(Collections.singletonList(topicPartition));

        System.out.println("------------------");
        System.out.println("Consumer " + this.consumerGroup + " consuming from topic " + this.topic + " partition " + this.partition);
        System.out.println("------------------");
        
        try {
            while (true) {
                ConsumerRecords<String, Object> records = consumer.poll(Duration.ofMillis(100));
                for (ConsumerRecord<String, Object> record : records) {
                    System.out.println("Consumer " + this.consumerGroup + " return from topic " + this.topic + " partition " + this.partition + " this: ");
                    System.out.println(record.value().toString());
                }
                consumer.commitAsync();
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e);
        } finally {
            consumer.close();
        }
    }
}